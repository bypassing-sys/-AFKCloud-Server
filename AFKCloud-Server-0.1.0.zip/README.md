# AFKCloud Server 0.1.0 — Android 16 host starter

This is a server-side starting point for AFKCloud using redroid, which documents support for Android 16.

## GitHub is not the cloud-phone host
GitHub stores code and runs temporary checks. GitHub Actions does not provide a persistent Android phone or a 24/7 server. A separate compatible Linux host is required.

## Host requirements
The Linux host must support Docker and the kernel features required by redroid, including binderfs / Android binder support. Not every VPS supports this.

## Security
- ADB is bound to 127.0.0.1 only.
- Never expose ADB port 5555 to the public internet.
- This starter has no customer authentication, tenant isolation, billing, streaming gateway, or production hardening.
- Google Play services are not bundled by default, so Play Store availability is not guaranteed.

## Run on a compatible Linux host (not GitHub Actions)
1. Install Docker on a compatible Linux host.
2. Ensure the host kernel has the redroid-required binder features/modules.
3. Run `docker compose up -d` from this folder.
4. Check `docker compose ps` and `docker logs afkcloud-android16`.

## Current scope
This defines one persistent Android 16 container and a data volume. It does not yet provide browser video, WebRTC streaming, remote touch input, customer accounts, multi-user provisioning, billing, or a public API. These need to be implemented and security-tested before public launch.

## Upstream documentation
https://github.com/remote-android/redroid-doc
